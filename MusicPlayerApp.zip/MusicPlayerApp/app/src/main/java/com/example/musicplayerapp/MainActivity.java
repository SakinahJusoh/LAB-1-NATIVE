package com.example.musicplayerapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startMusicButton = findViewById(R.id.startMusicButton);
        Button stopMusicButton = findViewById(R.id.stopMusicButton);

        // Start MusicService
        startMusicButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MusicService.class);
            startService(intent);  // Consider using startForegroundService() for API level 26+
        });

        // Stop MusicService
        stopMusicButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MusicService.class);
            stopService(intent);
        });
    }
}
